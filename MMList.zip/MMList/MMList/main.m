//
//  main.m
//  MMList
//
//  Created by Dry on 2018/3/14.
//  Copyright © 2018年 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MMList.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        MMList *list = [[MMList alloc] initWithData:0];
        //刚初始化的链表，首节点即尾节点
        NSLog(@"首节点数据：%@ ；尾节点：%@",list.head,list.hail);
        
        //新增数据
        for (int i = 1; i < 10; i++) {
            [list append:i];
        }
        NSLog(@"首节点数据：%@ ；尾节点：%@",list.head,list.hail);

        //输出
        [list printList];
        
        //逆转指针
        [list reverse];
        
        //再次输出
        [list printList];
    }
    return 0;
}
