//
//  MMList.m
//  MMList
//
//  Created by Dry on 2018/3/14.
//  Copyright © 2018年 Apple Inc. All rights reserved.
//

#import "MMList.h"

@implementation MMList

- (instancetype)initWithData:(int)data {
    if (self = [super init]) {
        
        //创建首节点
        self.head = [[MMNode alloc] init];
        self.head.data = data;
        self.head.next = nil;
        
        //设置尾节点
        self.hail = self.head;//新初始化的链表，尾节点就是首节点
    }
    return self;
}

- (void)append:(int)data {
    //创建新节点
    MMNode *node = [[MMNode alloc] init];
    node.data = data;
    node.next = nil;
    
    //之前的尾节点的next节点是现在新的节点
    self.hail.next = node;
    
    //将新节点设置成最新的尾节点
    self.hail = node;
}

- (void)printList {
    MMNode *current = self.head;
    while (current) {
        NSLog(@"%ld",(long)current.data);
        current = current.next;
    }
}

- (void)reverse {
    MMNode *prev = nil;
    MMNode *current = self.head;
    MMNode *next = nil;
    while (current) {
        next = current.next;
        current.next = prev;
        prev = current;
        current = next;
    }
    self.head = prev;
}

@end
