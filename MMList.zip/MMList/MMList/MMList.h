//
//  MMList.h
//  MMList
//
//  Created by Dry on 2018/3/14.
//  Copyright © 2018年 Apple Inc. All rights reserved.
//
//  链表类
//

#import <Foundation/Foundation.h>
#import "MMNode.h"

@interface MMList : NSObject

@property (nonatomic, strong) MMNode *head;//首节点
@property (nonatomic, strong) MMNode *hail;//尾节点

//初始化
- (instancetype)initWithData:(int)data;

//增加节点
- (void)append:(int)data;

//输出
- (void)printList;

@end
