//
//  MMNode.h
//  MMList
//
//  Created by Dry on 2018/3/14.
//  Copyright © 2018年 Apple Inc. All rights reserved.
//
//  节点类
//

#import <Foundation/Foundation.h>

@interface MMNode : NSObject

@property (nonatomic, assign) int data;//节点数据
@property (nonatomic, strong) MMNode *next;//下一个节点

@end
